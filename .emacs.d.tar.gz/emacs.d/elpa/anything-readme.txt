Start with M-x anything, narrow the list by typing some pattern,
select with up/down/pgup/pgdown/C-p/C-n/C-v/M-v, choose with enter,
left/right moves between sources.  With TAB actions can be selected
if the selected candidate has more than one possible action.

Note that anything.el provides only the framework and some example
configurations for demonstration purposes.  See anything-config.el
for practical, polished, easy to use configurations which can be
used to assemble a custom personalized configuration.

NOTE: What you find on Emacswiki is mostly deprecated and not maintained,
      don't complain if you use such code or configuration and something
      doesn't work.

Here is Japanese translation of `anything-sources' attributes.  Thanks.
http://d.hatena.ne.jp/sirocco634/20091012/1255336649


